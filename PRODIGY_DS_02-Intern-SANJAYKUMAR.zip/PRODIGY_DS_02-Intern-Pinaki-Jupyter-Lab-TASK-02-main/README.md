# PRODIGY_DS_02-Intern-Pinaki-Jupyter-Lab-TASK-02
As an Intern, I have created and completed in 12-14 days in Jupyter Lab as per the task of Prodigy InfoTech i.e., DATA SCIENCE ----TASK 2.
Task : Perform data cleaning and exploratory data analysis (EDA) on a dataset of your choice, such as the Titanic dataset from Kaggle. Explore the relationships between variables and identify patterns and trends in the data.


https://github.com/PINAKIMATHAN/PRODIGY_DS_02-Intern-Pinaki-Jupyter-Lab-TASK-02/assets/107812574/80271972-3197-485e-899d-ee688b8336d9

